INKCORA SHOPIFY THEME — Liquid 2.0
===================================

ESTRUCTURA DEL TEMA
-------------------
shopify-theme/
├── layout/
│   └── theme.liquid          ← Layout principal
├── templates/
│   ├── index.json            ← Página de inicio
│   ├── product.json          ← Página de producto
│   ├── collection.json       ← Página de colección
│   ├── page.json             ← Páginas estáticas
│   ├── blog.json             ← Blog
│   ├── article.json          ← Artículo del blog
│   ├── cart.json             ← Carrito
│   └── search.json           ← Búsqueda
├── sections/
│   ├── header.liquid         ← Encabezado con nav y anuncio
│   ├── header-group.json     ← Grupo de header
│   ├── footer.liquid         ← Pie de página
│   ├── footer-group.json     ← Grupo de footer
│   ├── hero.liquid           ← Hero principal (personalizable)
│   ├── featured-products.liquid ← Productos destacados
│   ├── trust-bar.liquid      ← Barra de confianza
│   └── rich-text.liquid      ← Sección CTA de texto
├── snippets/
│   └── product-card.liquid   ← Tarjeta de producto reutilizable
├── assets/
│   ├── base.css              ← Estilos base del tema
│   ├── theme.js              ← JavaScript del tema
│   └── global.js             ← Utilidades globales
├── locales/
│   └── en.default.json       ← Traducciones en inglés
└── config/
    ├── settings_schema.json  ← OPCIONES DEL EDITOR DE SHOPIFY
    └── settings_data.json    ← Valores por defecto

INSTALACIÓN EN SHOPIFY
----------------------
1. Descarga el ZIP de este proyecto
2. En Shopify Admin → Online Store → Themes
3. Click "Add theme" → "Upload ZIP file"
4. Sube el ZIP de la carpeta shopify-theme/
5. Click "Customize" para personalizar desde el editor

PERSONALIZACIÓN DESDE EL EDITOR
---------------------------------
Las siguientes opciones están disponibles en el editor de Shopify:

COLORES:
- Color de acento (botones, enlaces)
- Color oscuro (navy — hero, secciones)
- Fondo principal y secundario
- Colores de texto

TIPOGRAFÍA:
- Fuente de títulos (default: Cormorant Garamond)
- Fuente de texto (default: DM Sans)
- Escala de tamaños

DISEÑO:
- Ancho máximo de página
- Espacio entre secciones
- Animaciones de scroll y hover

LOGO Y FAVICON:
- Logo personalizado
- Favicon
- Ancho del logo

TARJETAS DE PRODUCTO:
- Estilo, radio, proporción
- Muestras de color
- Quick add

TEMA:
- 3 estilos: Clásico, Cálido, Audaz
- Barra de anuncio
- Número de teléfono
- CSS personalizado

SECCIONES DISPONIBLES (arrastra en el editor):
- Hero principal
- Barra de confianza
- Productos destacados
- Texto enriquecido con CTA
- Encabezado / Pie de página

PRÓXIMOS PASOS:
1. Agregar sección main-product.liquid para producto individual
2. Agregar sección main-collection.liquid para colecciones
3. Integrar SB Custom Product Personalizer desde Shopify App Store
4. Configurar metafields para técnicas de impresión por producto
